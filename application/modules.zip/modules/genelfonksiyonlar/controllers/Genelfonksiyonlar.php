<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Classified admin Controller
 *
 * This class handles admin management related functionality
 *
 * @package		Genelfonkiyonlar
 * @subpackage	Genelfonkiyonlar
 * @author		I.M.D.A.T
 * @link		http://webhelios.com
 */
require_once'Genelfonksiyonlar_core.php';
class Genelfonksiyonlar extends Genelfonksiyonlar_core {

	public function __construct()
	{
		parent::__construct();
	}
}