<link href="<?php echo base_url();?>assets/admin2/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/admin2/css/jquery.multiselect.css" rel="stylesheet">
	
    <link href="<?php echo base_url();?>assets/admin2/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/admin2/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- FooTable -->
    <link href="<?php echo base_url();?>assets/admin2/css/plugins/footable/footable.core.css" rel="stylesheet">

    <link href="<?php echo base_url();?>assets/admin2/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/admin2/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/admin2/css/ozel.css" rel="stylesheet">
	
	
	<link href="<?php echo base_url();?>assets/admin/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/admin/font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
   <link href="<?php echo base_url();?>assets/admin/css/plugins/toastr/toastr.min.css" rel="stylesheet">

<!--    <link href="<?php echo base_url();?>assets/admin/css/plugins/iCheck/custom.css" rel="stylesheet">-->

<!--    <link href="<?php echo base_url();?>assets/admin/css/plugins/chosen/chosen.css" rel="stylesheet">-->

<!--    <link href="<?php echo base_url();?>assets/admin/css/plugins/colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet">-->

<!--    <link href="<?php echo base_url();?>assets/admin/css/plugins/cropper/cropper.min.css" rel="stylesheet">-->

<!--    <link href="<?php echo base_url();?>assets/admin/css/plugins/switchery/switchery.css" rel="stylesheet">-->

<!--    <link href="<?php echo base_url();?>assets/admin/css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">-->

<!--    <link href="<?php echo base_url();?>assets/admin/css/plugins/nouslider/jquery.nouislider.css" rel="stylesheet">-->

    <link href="<?php echo base_url();?>assets/admin/css/plugins/datapicker/datepicker3.css" rel="stylesheet">

<!--    <link href="<?php echo base_url();?>assets/admin/css/plugins/ionRangeSlider/ion.rangeSlider.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/admin/css/plugins/ionRangeSlider/ion.rangeSlider.skinFlat.css" rel="stylesheet">-->

    <link href="<?php echo base_url();?>assets/admin/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">

    <link href="<?php echo base_url();?>assets/admin/css/plugins/clockpicker/clockpicker.css" rel="stylesheet">

<!--    <link href="<?php echo base_url();?>assets/admin/css/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet">-->

    <link href="<?php echo base_url();?>assets/admin/css/plugins/select2/select2.min.css" rel="stylesheet">

    <!-- Data Tables -->
    <link href="<?php echo base_url();?>assets/admin/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/admin/css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/admin/css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">

    <link href="<?php echo base_url();?>assets/admin/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/admin/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/admin/css/ozel.css" rel="stylesheet">
	
	<!--<link href="<?php echo base_url();?>assets/admin/css/jquery.multiselect.css" rel="stylesheet">-->
	

	
	
	    <!-- Mainly scripts -->
    <script src="<?php echo base_url();?>assets/admin/js/jquery-2.1.1.js"></script>
    <script src="<?php echo base_url();?>assets/admin/js/jquery-ui-1.10.4.min.js"></script>
    <script src="<?php echo base_url();?>assets/admin/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/admin/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url();?>assets/admin/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>	
	
	<!--<script src="<?php echo base_url();?>assets/admin/js/jquery.multiselect.js"></script>
	 <link href="<?php echo base_url();?>assets/admin/css/sumoselect.css" rel="stylesheet" />
	<script src="<?php echo base_url();?>assets/admin/js/jquery.sumoselect.js"></script>-->
	
	
	
	
	<script type="text/javascript">
        $(document).ready(function () {
		
         //   window.testSelAll2 = $('.testSelAll2').SumoSelect({selectAll:true });
           
   	   
		   
        });
    </script>

	

	
	    <!-- Sweet Alert -->
    <link href="<?php echo base_url();?>assets/admin/css/plugins/sweetalert/sweetalert.css" rel="stylesheet">
