<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-sm-9">
                    <h2>OKUL &amp; ŞUBE SEÇENEKLERİ</h2>
                    <p>Okul ve şube seçeneklerini oluşturabilir, düzenleyebilir veya silebilirsiniz.</p>
                </div>
                <!--info button-->
                <div class="col-sm-3 title-action">
                    <a href="<?php echo base_url().'genelayarlar/yetkiislemleri';?>"><button class="btn btn-info btn-lg" type="button" title="Liste"><i class="fa fa-list"></i> </button></a>
                    <a href="<?php echo base_url().'genelayarlar/yetkiislemleriekle';?>"><button class="btn btn-success btn-lg" name="eklebutonu" id="eklebutonu" type="button" title="Yeni"><i class="fa fa-plus"></i> </button></a>
                    <a href="javascript:history.back(-1)"><button class="btn btn-default btn-outline btn-lg" type="button" title="Önceki"><i class="fa fa-reply"></i> </button></a>
                </div><!--#info button-->
            </div>